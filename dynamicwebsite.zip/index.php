
<?php
include('includes/sessionstart.php');
include('includes/header.php');
?>
                    
                       <div class="col-md-12">
                              <img src="image/banner.jpg" alt="Banner" class="w-100"></div>
                       <div class="col-md-8">
                              Post
                       </div>
                       
<?php
      include('includes/footer.php');
?>